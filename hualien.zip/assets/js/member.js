$(function() {
    $("#header").load("./header_member.html");
    $("#footer").load("./footer.html");
});